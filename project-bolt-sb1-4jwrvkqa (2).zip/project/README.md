# Student Feedback Portal

A modern, responsive **Student Feedback Module** for a college. Students can submit feedback about subjects and teachers with a star rating system. All feedback is stored securely in a cloud database.

## Features

- **Student Feedback Form** with name, roll number, subject dropdown, star rating, and message
- **Interactive Star Rating** (1–5) with hover preview and live rating labels (Poor → Excellent)
- **Character Counter** for the feedback message (500 character max)
- **Form Validation** — both client-side and server-side, with inline error messages
- **Success Confirmation** — animated success banner with submission details after each submit
- **Reset Button** — clears the form and all errors
- **Loading State** — submit button shows a spinner and disables during submission to prevent duplicates
- **Stats Dashboard** — shows total submissions, average rating, and subject count
- **Recent Feedback** — displays the 5 most recent submissions
- **Responsive Design** — works on mobile, tablet, and desktop
- **Accessible** — keyboard navigation, ARIA labels, focus indicators, and screen-reader support

## Tech Stack

| Layer      | Technology                          |
| ---------- | ----------------------------------- |
| Frontend   | React 18 + Vite                     |
| Styling    | CSS3 (custom design system)         |
| Icons      | lucide-react                        |
| Backend    | Supabase (PostgreSQL + REST API)    |
| Database   | Supabase (auto-provisioned)         |

## Project Structure

```
├── index.html              # HTML entry point
├── vite.config.js          # Vite configuration
├── package.json            # Dependencies and scripts
├── public/
│   └── favicon.svg         # College-themed favicon
└── src/
    ├── main.jsx            # React entry point
    ├── App.jsx             # Main app component (form, validation, UI)
    ├── supabaseClient.js   # Supabase client setup
    └── style.css           # Complete styling
```

## Installation & Running

### Prerequisites
- Node.js 18+ and npm

### Steps

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Run the development server:**
   ```bash
   npm run dev
   ```

3. **Open the app** in your browser at the URL shown in the terminal (typically `http://localhost:5173`).

### Build for Production

```bash
npm run build
npm run preview
```

## Database

The app uses a Supabase PostgreSQL database (auto-provisioned). The `student_feedback` table stores:

| Column          | Type       | Description                        |
| --------------- | ---------- | ---------------------------------- |
| id              | uuid (PK)  | Auto-generated unique ID           |
| student_name    | text       | Student's name                     |
| roll_number     | text       | Student's roll number              |
| subject         | text       | Selected subject or teacher        |
| rating          | integer    | Star rating (1–5, CHECK constraint)|
| message         | text       | Feedback message                   |
| created_at      | timestamptz| Auto-generated submission timestamp|

Row Level Security (RLS) is enabled with open CRUD policies for the anon and authenticated roles, since this is a public feedback portal without sign-in.

## Form Validation Rules

- **Student Name**: required, minimum 2 characters, not just whitespace
- **Roll Number**: required, minimum 2 characters, not just whitespace
- **Subject**: must select one option from the dropdown
- **Rating**: must be an integer between 1 and 5
- **Feedback Message**: required, minimum 10 characters, maximum 500 characters, not just whitespace

All entered data is preserved if validation fails — the user does not lose what they typed.

## Testing

1. Open the app in the browser.
2. Try submitting an empty form — you should see inline error messages for each missing field.
3. Fill in all fields, select a star rating, and type a feedback message.
4. Click **Submit Feedback** — the button shows a loading spinner.
5. After submission, a green success banner appears with the subject, rating, and timestamp.
6. The form resets, and the new feedback appears in the **Recent Feedback** list below.
7. Click **Reset Form** at any time to clear all fields.
8. Resize the browser window to verify the responsive layout on mobile and tablet widths.

## Subjects Available

- Data Structures
- Python Programming
- Discrete Structures
- Computer Organization
- Technical Communication
- Faculty Feedback
